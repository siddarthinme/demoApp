package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DemoController {

    @Autowired
    private MessageRepository messageRepository;

    // Endpoint to return a hello world message
    @RequestMapping("/")
    public String helloworld() {
        return "Hello World";
    }

    // Endpoint to receive data and save it to the database
    @PostMapping("/data")
    public String receiveData(@RequestBody String data) {
        Message message = new Message();
        message.setMessage(data);
        messageRepository.save(message);
        return "Data received and saved";
    }

    // Endpoint to get all messages from the database
    @GetMapping("/data")
    public List<Message> getData() {
        return messageRepository.findAll();
    }

    // New endpoint to add a message directly to the database
    @PostMapping("/addMessage")
    public String addMessage(@RequestBody Message message) {
        messageRepository.save(message);
        return "Message added to database";
    }
}
